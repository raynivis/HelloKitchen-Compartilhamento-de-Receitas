export interface UserToken {
    access_token: string;
    token_type: string;
  }