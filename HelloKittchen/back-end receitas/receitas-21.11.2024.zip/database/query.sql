INSERT INTO category
VALUES (1, DATE('now'), DATE('now'), 'Aves');
INSERT INTO category
VALUES (2, DATE('now'), DATE('now'), 'Salgados');
INSERT INTO category
VALUES (3, DATE('now'), DATE('now'), 'Peixes');
INSERT INTO category
VALUES (4, DATE('now'), DATE('now'), 'Carnes');
INSERT INTO category
VALUES (5, DATE('now'), DATE('now'), 'Sobremesas');
INSERT INTO category
VALUES (6, DATE('now'), DATE('now'), 'Bolos');
